package com.filesample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FilesampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(FilesampleApplication.class, args);
	}

}
